package com.example.demo.spring;

public interface Connection {
public String getConnection();
}
