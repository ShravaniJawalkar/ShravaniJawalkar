package com.example.demo.xmlproject;

public class XmlConstructorInjection {
public XmlConstructorInjection() {
	System.out.println("constructor injection");
}
}
