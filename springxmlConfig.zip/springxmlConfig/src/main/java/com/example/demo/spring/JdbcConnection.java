package com.example.demo.spring;



//import org.springframework.stereotype.Component;

public class JdbcConnection implements Connection {

	@Override
	public String getConnection() {
		// TODO Auto-generated method stub
		return "JDBC Connection";
	}

}
