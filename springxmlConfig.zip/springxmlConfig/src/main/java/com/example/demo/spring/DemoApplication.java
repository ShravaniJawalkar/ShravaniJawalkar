package com.example.demo.spring;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class DemoApplication {
private static Logger log=LoggerFactory.getLogger(DemoApplication.class);
	public static void main(String[] args) {
		ClassPathXmlApplicationContext applicationContext= new ClassPathXmlApplicationContext("xmlStringBootApp.xml");
		PersonDao personDao=applicationContext.getBean(PersonDao.class);
		System.out.println(personDao);
		System.out.println(personDao.getJdbcConnection());
		log.info("{}"+personDao);
		log.info("{}"+personDao.getSqlConnection());
		applicationContext.close();
		
	}

}
