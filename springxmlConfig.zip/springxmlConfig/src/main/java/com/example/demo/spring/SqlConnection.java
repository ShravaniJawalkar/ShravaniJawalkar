package com.example.demo.spring;

public class SqlConnection implements Connection {

	@Override
	public String getConnection() {
		// TODO Auto-generated method stub
		return "SqlConnection";
	}

}
