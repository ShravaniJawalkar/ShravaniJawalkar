package com.example.demo.xmlproject;

public class XmlChildConnection {

public XmlChildConnection() {
	System.out.println("xmlChildConnection");
}
}
