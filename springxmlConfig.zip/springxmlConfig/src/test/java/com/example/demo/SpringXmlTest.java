package com.example.demo;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.spring.JdbcConnection;
import com.example.demo.spring.SqlConnection;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = "/TestXml.xml")
public class SpringXmlTest {
	
	@Autowired
	SqlConnection sqlConnection;
	
	@Autowired
	JdbcConnection jdbcConnection;
	
	@Test
	public void testSqlConnection() {
		assertEquals("SqlConnection", sqlConnection.getConnection());
	}

	@Test
	public void testJdbcConnection() {
		assertEquals("JDBC Connection", jdbcConnection.getConnection());
	}
}
