package com.example.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.spring.DemoApplication;
import com.example.demo.spring.JdbcConnection;


@RunWith(SpringRunner.class)
@ContextConfiguration(locations = "/xmlStringBootApp.xml")
public class DemoApplicationTests {
	@Autowired
	JdbcConnection jdbcConnection;

	@Test
	public void contextLoads() {
		jdbcConnection.getConnection();
	}

}
